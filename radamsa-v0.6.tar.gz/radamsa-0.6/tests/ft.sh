#!/bin/sh

echo zombieslartibartfasterthaneelslartibartfastenyourseatbelts | $@ -m ft -p od -n 60 | grep -q zombieslartibartfastenyourseatbelts || exit 1

